import React from 'react';

function Hello(){
  return (
	<div>
		<h1>Hello React </h1>
		<ul>
			<li>Rahel</li>
			<li>Hikma</li>
			<li>Jemila</li>
		</ul>
	</div>
  );
}


export default Hello;
